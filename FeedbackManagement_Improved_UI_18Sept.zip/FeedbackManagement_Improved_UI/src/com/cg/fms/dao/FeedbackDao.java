package com.cg.fms.dao;

import java.util.ArrayList;

import com.cg.fms.dto.Feedback;
import com.cg.fms.exception.FMSException;

public interface FeedbackDao {
	
	public ArrayList<Feedback> getFeedbackByParticipantId(int id) throws FMSException;  
	public ArrayList<Feedback> getFeedbackByTrainingId(int id) throws FMSException;  
	public ArrayList<Feedback> getAllFeedbacks() throws FMSException;
	public int  addFeedback(Feedback feedback) throws FMSException;
	public ArrayList<Feedback> getDefaulters() throws FMSException;
	public ArrayList joinTrainingWithFeed(int month) throws FMSException;
	public ArrayList defaultersFeedback(int month) throws FMSException;
	public ArrayList facultyFeedback(int id, int month) throws FMSException;
	public Feedback findFeedbackByPIdAndTCode(int pId, int tCode) throws FMSException;
	

}
