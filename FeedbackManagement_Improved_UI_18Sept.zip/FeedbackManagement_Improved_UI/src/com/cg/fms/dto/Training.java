package com.cg.fms.dto;

import java.time.LocalDate;

public class Training {
	private int trainingCode;
	private int courseCode;
	private int facultyCode;
	private LocalDate startDate;
	private LocalDate endDate;
	public int getTrainingCode() {
		return trainingCode;
	}
	public void setTrainingCode(int trainingCode) {
		this.trainingCode = trainingCode;
	}
	public int getCourseCode() {
		return courseCode;
	}
	public void setCourseCode(int courseCode) {
		this.courseCode = courseCode;
	}
	public int getFacultyCode() {
		return facultyCode;
	}
	public void setFacultyCode(int facultyCode) {
		this.facultyCode = facultyCode;
	}
	public LocalDate getStartDate() {
		return startDate;
	}
	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}
	public LocalDate getEndDate() {
		return endDate;
	}
	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}
	public Training(int trainingCode, int courseCode, int facultyCode,
			LocalDate startDate, LocalDate endDate) {
		super();
		this.trainingCode = trainingCode;
		this.courseCode = courseCode;
		this.facultyCode = facultyCode;
		this.startDate = startDate;
		this.endDate = endDate;
	}
	public Training() {
		super();
	}
	@Override
	public String toString() {
		return "Training [trainingCode=" + trainingCode + ", courseCode="
				+ courseCode + ", facultyCode=" + facultyCode + ", startDate="
				+ startDate + ", endDate=" + endDate + "]";
	}
	public Training(int courseCode, int facultyCode, LocalDate startDate, LocalDate endDate) {
		super();
		this.courseCode = courseCode;
		this.facultyCode = facultyCode;
		this.startDate = startDate;
		this.endDate = endDate;
	}
	
	
	
	
	
	

}
