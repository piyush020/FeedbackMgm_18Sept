package com.cg.fms.service;

import java.util.ArrayList;

import com.cg.fms.dto.Employee;
import com.cg.fms.exception.FMSException;

public interface EmployeeService {
	public Employee getEmployeeById(int id) throws FMSException;  
	public Employee getEmployeeByName(String name) throws FMSException;  
	public ArrayList<Employee> getAllEmployees() throws FMSException;
	public Employee addEmployee(Employee emp) throws FMSException;
	public Employee updateEmployee(Employee emp) throws FMSException;
	public boolean deleteEmployee(int id) throws FMSException;
	boolean validateId(int id) throws FMSException;
	
}
